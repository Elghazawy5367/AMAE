# How to Deploy AMAE to GitHub
## Works on any device with a browser (Samsung tablet, Windows 7, anything)

---

## What you need
- [ ] This file: `AMAE_v3_FINAL.zip` (your repo)
- [ ] This file: `deploy-to-github.js` (this script)
- [ ] A GitHub account (free)
- [ ] A Replit account (free) → replit.com

---

## Step 1 — Create your GitHub repo (2 min)

1. Go to **github.com** in your browser
2. Click **+** → **New repository**
3. Name it: `amae`
4. Set to **Private**
5. **Do NOT** check "Initialize with README" — leave it empty
6. Click **Create repository**

---

## Step 2 — Get a GitHub Token (2 min)

1. Go to **github.com → Settings** (your profile picture → Settings)
2. Scroll down → **Developer settings** (bottom left)
3. **Personal access tokens** → **Tokens (classic)**
4. **Generate new token (classic)**
5. Note: "AMAE deploy"
6. Expiration: 7 days (enough for this)
7. Check **repo** (all boxes under it) and **workflow**
8. Click **Generate token**
9. **Copy it immediately** — starts with `ghp_...` — you won't see it again

---

## Step 3 — Set up Replit (3 min)

1. Go to **replit.com** → Sign up free
2. **Create a Repl** → Choose **Node.js**
3. In the Files panel (left sidebar), click **Upload file**
4. Upload **both files**:
   - `AMAE_v3_FINAL.zip`
   - `deploy-to-github.js`
5. Also upload `package.json` from this folder
6. Click on `deploy-to-github.js` to open it

---

## Step 4 — Fill in your details (1 min)

At the top of `deploy-to-github.js`, change these 3 lines:

```
const GITHUB_OWNER = 'YOUR_GITHUB_USERNAME';   ← your GitHub username
const GITHUB_REPO  = 'amae';                    ← keep as-is if you named it amae
const GITHUB_TOKEN = 'ghp_YOUR_TOKEN_HERE';     ← paste your token from Step 2
```

---

## Step 5 — Run it (4 min)

1. Click the **Run** button (green, top of Replit)
2. Watch the console — you'll see each file being pushed
3. Takes about 4 minutes for 179 files
4. Done when you see: `✅ Deployed: 179/179 files`

---

## Step 6 — Verify

Go to `github.com/YOUR_USERNAME/amae` — you should see all your folders and files.

---

## Next step after deployment

Open `config/product-dna.json` in your GitHub repo and fill it in.
That's the only file you need to edit before the system runs.

Read `SETUP.md` for the full onboarding guide.
