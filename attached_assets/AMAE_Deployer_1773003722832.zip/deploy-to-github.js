// ============================================================
// AMAE → GitHub Deployer
// Run this on Replit (free) to push all 179 files to your repo
// in one script — no terminal, no git, no GitHub Desktop needed
// ============================================================
//
// SETUP (5 minutes):
// 1. Go to replit.com → Create a Node.js Repl
// 2. Upload deploy-to-github.js AND AMAE_v3_FINAL.zip to Replit
// 3. Fill in the three variables below (OWNER, REPO, TOKEN)
// 4. Click Run
//
// WHERE TO GET YOUR GITHUB TOKEN:
// github.com → Settings → Developer settings → Personal access tokens
// → Tokens (classic) → Generate new token
// → Check: repo (all), workflow
// → Copy the token (starts with ghp_...)
// ============================================================

import { readFileSync, existsSync } from 'fs';
import { execSync } from 'child_process';
import path from 'path';

// ── FILL THESE IN ──────────────────────────────────────────
const GITHUB_OWNER = 'YOUR_GITHUB_USERNAME';   // e.g. 'ahmedfarouk'
const GITHUB_REPO  = 'amae';                    // your new empty private repo name
const GITHUB_TOKEN = 'ghp_YOUR_TOKEN_HERE';     // from github.com/settings/tokens
// ──────────────────────────────────────────────────────────

const API = 'https://api.github.com';
const HEADERS = {
  'Authorization': `Bearer ${GITHUB_TOKEN}`,
  'Accept': 'application/vnd.github+json',
  'Content-Type': 'application/json',
  'X-GitHub-Api-Version': '2022-11-28',
};

// ── Unzip the AMAE archive ─────────────────────────────────
const ZIP_NAME = 'AMAE_v3_FINAL.zip';
const EXTRACT_DIR = './amae_extracted';

if (!existsSync(ZIP_NAME)) {
  console.error(`❌ ${ZIP_NAME} not found. Upload it to Replit first.`);
  process.exit(1);
}

console.log('📦 Extracting ZIP...');
try {
  execSync(`unzip -o ${ZIP_NAME} -d ${EXTRACT_DIR}`, { stdio: 'inherit' });
} catch (e) {
  // Try installing unzip if not available
  console.log('Installing unzip...');
  execSync('apt-get install -y unzip 2>/dev/null || true');
  execSync(`unzip -o ${ZIP_NAME} -d ${EXTRACT_DIR}`, { stdio: 'inherit' });
}

// ── Collect all files ──────────────────────────────────────
function walkDir(dir, fileList = []) {
  const entries = execSync(`find "${dir}" -type f`, { encoding: 'utf8' })
    .split('\n').filter(Boolean);
  return entries;
}

const allFiles = walkDir(EXTRACT_DIR);
console.log(`\n📁 Found ${allFiles.length} files to push\n`);

// ── Push each file to GitHub ───────────────────────────────
async function pushFile(localPath, repoPath) {
  const content = readFileSync(localPath);
  const b64 = content.toString('base64');

  // Check if file already exists (to get its SHA for update)
  let sha = undefined;
  try {
    const checkRes = await fetch(`${API}/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${repoPath}`, {
      headers: HEADERS,
    });
    if (checkRes.ok) {
      const existing = await checkRes.json();
      sha = existing.sha;
    }
  } catch { /* file doesn't exist yet — that's fine */ }

  const body = {
    message: `deploy: add ${repoPath}`,
    content: b64,
    ...(sha ? { sha } : {}),
  };

  const res = await fetch(
    `${API}/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${repoPath}`,
    { method: 'PUT', headers: HEADERS, body: JSON.stringify(body) }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(`${res.status} ${JSON.stringify(err)}`);
  }
  return res.status;
}

// ── Main deployment loop ───────────────────────────────────
async function deploy() {
  if (GITHUB_TOKEN === 'ghp_YOUR_TOKEN_HERE') {
    console.error('❌ Fill in GITHUB_OWNER, GITHUB_REPO, and GITHUB_TOKEN at the top of this file.');
    process.exit(1);
  }

  // Verify repo exists
  const repoCheck = await fetch(`${API}/repos/${GITHUB_OWNER}/${GITHUB_REPO}`, {
    headers: HEADERS
  });
  if (!repoCheck.ok) {
    console.error(`❌ Repo ${GITHUB_OWNER}/${GITHUB_REPO} not found or token lacks access.`);
    console.error('   Create the repo first at github.com → New repository');
    process.exit(1);
  }
  console.log(`✅ Repo verified: github.com/${GITHUB_OWNER}/${GITHUB_REPO}\n`);

  let done = 0, failed = [];

  for (const localPath of allFiles) {
    // Convert local path to repo path
    // e.g. ./amae_extracted/amae/agents/foo.js → agents/foo.js
    let repoPath = localPath
      .replace(`${EXTRACT_DIR}/`, '')
      .replace(/^amae\//, '');     // strip the amae/ root folder

    // Skip .gitkeep files that would be redundant, but keep directory markers
    // Include all files
    process.stdout.write(`  [${done+1}/${allFiles.length}] ${repoPath}...`);

    try {
      const status = await pushFile(localPath, repoPath);
      process.stdout.write(` ${status === 201 ? '✅ created' : '🔄 updated'}\n`);
      done++;
    } catch (err) {
      process.stdout.write(` ❌ FAILED: ${err.message}\n`);
      failed.push({ repoPath, error: err.message });
    }

    // Small delay to respect rate limits (stays well under 5000/hr)
    await new Promise(r => setTimeout(r, 150));
  }

  console.log('\n' + '='.repeat(50));
  console.log(`✅ Deployed: ${done}/${allFiles.length} files`);
  if (failed.length > 0) {
    console.log(`❌ Failed: ${failed.length} files`);
    failed.forEach(f => console.log(`   - ${f.repoPath}: ${f.error}`));
  }
  console.log(`\n🎯 Your repo: https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}`);
  console.log(`\nNext: Fill in config/product-dna.json and you're ready for first run.`);
}

deploy().catch(err => {
  console.error('Deployment failed:', err.message);
  process.exit(1);
});
